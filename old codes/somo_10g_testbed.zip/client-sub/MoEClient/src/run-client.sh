#!/bin/bash
java -cp .:../* MoEClient
