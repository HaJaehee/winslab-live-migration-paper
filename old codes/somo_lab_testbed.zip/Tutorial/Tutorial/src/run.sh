#!/bin/bash
java -cp .:../* -d64 -Xmx4g SOMODHTServer 0
