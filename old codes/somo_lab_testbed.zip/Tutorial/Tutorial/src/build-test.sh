#!/bin/bash
javac -cp .:../* -d . DHTTest.java
