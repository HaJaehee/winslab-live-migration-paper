#!/bin/bash
javac -cp .:../* -d . MoEClient.java
