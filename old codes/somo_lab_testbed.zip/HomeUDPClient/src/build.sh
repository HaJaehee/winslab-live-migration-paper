#!/bin/bash
javac -cp .:../* -d . UDPClient.java
