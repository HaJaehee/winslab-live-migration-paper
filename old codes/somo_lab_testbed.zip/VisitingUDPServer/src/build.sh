#!/bin/bash
javac -cp .:../* -d . UDPServer.java
