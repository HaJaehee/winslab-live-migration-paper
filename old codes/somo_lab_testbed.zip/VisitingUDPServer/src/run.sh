#!/bin/bash
java -cp .:../* UDPServer
