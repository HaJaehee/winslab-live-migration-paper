#ifndef __CR_SERVICE_CONST_H__
#define __CR_SERVICE_CONST_H__

#define CR_MAX_MSG_SIZE 1024
#define CR_DEFAULT_SERVICE_ADDRESS "/var/run/criu_service.socket"

#endif /* __CR_SERVICE_CONST_H__ */
