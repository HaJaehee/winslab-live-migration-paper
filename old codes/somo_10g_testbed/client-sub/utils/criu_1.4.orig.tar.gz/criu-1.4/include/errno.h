#ifndef __CR_ERRNO_H__
#define __CR_ERRNO_H__

#define ERESTARTSYS		512
#define ERESTARTNOINTR		513
#define ERESTARTNOHAND		514
#define ERESTART_RESTARTBLOCK	516

#endif /* __CR_ERRNO_H__ */
