#!/bin/sh

exec expect ./job.exp
