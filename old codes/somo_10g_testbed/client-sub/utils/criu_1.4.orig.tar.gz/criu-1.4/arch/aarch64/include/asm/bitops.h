#ifndef __CR_ASM_BITOPS_H__
#define __CR_ASM_BITOPS_H__

#include "compiler.h"
#include "asm-generic/bitops.h"

#endif /* __CR_ASM_BITOPS_H__ */
