#ifndef __CR_ASM_STRING_H__
#define __CR_ASM_STRING_H__

#include "compiler.h"
#include "asm-generic/string.h"

#endif /* __CR_ASM_STRING_H__ */
