#ifndef __CR_INC_DUMP_H__
#define __CR_INC_DUMP_H__
#include "asm/dump.h"
#endif
