from coredump import *
import elf
