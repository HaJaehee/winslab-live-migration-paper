void what_err_ret_mean(int ret);
int chk_exit(int status, int want);
