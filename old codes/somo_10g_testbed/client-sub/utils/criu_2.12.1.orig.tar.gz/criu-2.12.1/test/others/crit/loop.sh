#!/bin/bash
while :; do
	sleep 1
done
