#ifndef __CR_BITSPERLONG_H__
#define __CR_BITSPERLONG_H__

#define BITS_PER_LONG 64

#endif /* __CR_BITSPERLONG_H__ */
