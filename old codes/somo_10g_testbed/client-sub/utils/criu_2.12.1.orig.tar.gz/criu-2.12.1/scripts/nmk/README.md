NMK
===

NMK stands for NetMaKe --  is a very simple framework for make build system.
Most ideas are taken from the Linux kernel kbuild system.
