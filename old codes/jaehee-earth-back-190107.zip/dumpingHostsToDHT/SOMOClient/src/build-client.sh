#!/bin/bash
javac -cp .:../* -d . SOMOClient.java
