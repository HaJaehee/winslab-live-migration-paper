#!/bin/bash
java -cp .:../* SOMOClient $1
