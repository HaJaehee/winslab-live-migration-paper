#!/bin/bash
java -cp .:../* DHTTest 0
