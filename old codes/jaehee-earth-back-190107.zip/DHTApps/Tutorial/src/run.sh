#!/bin/bash
java -cp .:../* -d64 -Xmx4g SOMODHTServer 1 10.16.0.1 8468 
