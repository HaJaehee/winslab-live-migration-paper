#!/bin/bash
javac -cp .:../* -d . SOMODHTServer.java
