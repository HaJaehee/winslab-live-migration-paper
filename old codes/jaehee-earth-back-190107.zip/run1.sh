sudo ifconfig p1p1 mtu 1500
sudo ifconfig p1p2 mtu 1500
sudo ifconfig p4p1 mtu 1500
sudo ifconfig p4p2 mtu 1500
sudo ifconfig s2 mtu 1500
