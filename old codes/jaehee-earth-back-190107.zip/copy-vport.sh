#!/bin/bash
sudo cp vport.c ./ovs-master/openvswitch-2.3.1_somo/datapath/
sudo cp vport.c ./ovs-master/openvswitch-2.3.1_somo/datapath/linux
