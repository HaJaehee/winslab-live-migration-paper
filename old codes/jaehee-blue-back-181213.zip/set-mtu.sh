#!/bin/bash
sudo ifconfig virnat0 mtu 1400
