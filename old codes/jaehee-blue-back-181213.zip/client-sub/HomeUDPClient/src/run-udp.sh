#!/bin/bash
java -cp .:../* UDPClient
