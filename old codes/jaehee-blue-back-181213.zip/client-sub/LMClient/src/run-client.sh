#!/bin/bash
java -cp .:../* SOMOClient
